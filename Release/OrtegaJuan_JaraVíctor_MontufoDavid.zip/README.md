# Pinball Nintendo Game

This game has been done and programmed by three students of TTC (Tech Talent Center) in Barcelona.
Is a remake of the game developed and released by Nintendo for the console NES, in 198e.

## Installation

Unzip the realese folder and execute the .exe file.


## Usage

###Normal keys:

← ➣ Move left paddles

→ ➣ Move right paddles

Space bar ➣ Throw ball, hold it for more power

###Debug modes keys:

F1 ➣ Show colliders, sensors, joints,...

1 ➣ Summon one ball

##Win lose condition

"Win" ➣ Get as many points as you can.

Lose ➣ Having unavailable balls left.


## Credits

Github project page: https://github.com/MrPollito/PinballPhysicsGame

David Montufo's Github account

 - Github: https://github.com/Montuuh


Juan Ortega's Github account

 - Github: https://github.com/MrPollito

Víctor Jara's Github account
 - Github: https://github.com/Kerali

CITM TTC Barcelona 2020-2021